This JRebel ZIP distribution is meant to be used without an IDE.

JRebel license activation
=========================

To activate the JRebel license from the command line, please run:

bin/activate.{cmd|sh} <ACTIVATION_KEY_OR_PATH_TO_LICENSE_FILE>

To activate the JRebel license using the provided activation wizard, please run:

bin/activate-gui.{cmd|sh}

Further information
===================

JRebel Learn Center: http://zeroturnaround.com/software/jrebel/learn/

JRebel Reference Manual: http://manuals.zeroturnaround.com/jrebel/